# Author-review typesetting source

Run `make pdf` with latexmk and a standard TeX installation. The build timestamp
is retained from the reviewed version. This archive contains only active
manuscript inputs and the generated bibliography; it is not an approved arXiv
upload. Author review, authorship/disclosure approval, and submission choices
remain pending. See the companion frozen-evidence reproduction archive for
figure generation and numerical checks.
