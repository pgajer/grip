# Focused-paper evidence

The namespaces `study-initializers` and `study-radius` contain byte-preserving
exports from the grip repository. Their original study documentation is
retained as provenance; links within those documents refer to the original
experiment trees, not to a complete mirror here.

`source-manifest.json` records the full source commit and source/export SHA-256
hashes. CSV files are deterministically compressed, without changing their
contents. Normal manuscript rendering uses these local exports and does not
require the grip repository or private planning files.

To verify the exports from the manuscript directory:

```sh
python3 scripts/verify_focused_evidence.py
```

To intentionally refresh them from a specified committed grip checkout:

```sh
python3 scripts/export_focused_evidence.py --grip-source /path/to/grip
```

The importer rejects selected source files that differ from that checkout's
HEAD. Refreshing changes provenance and requires renewed comparison review.
Full fitting scripts and larger input/coordinate archives remain canonical in
the source experiment directories recorded by the manifest.

The two studies have different domains, samples, targets and scale policies.
Their settings must not be pooled as independent sample replications. Existing
verification records document the original analyses; the focused manuscript's
additional checks are recorded separately.
